import random

def roll_die ():
    roll = random.randint(1,6)
    return roll

def roll_two_die (dice):
    dice[0] = roll_die ()
    dice[1] = roll_die ()

def sum_dice (dice):
    sum_of_dice = dice[0] + dice[1]
    return sum_of_dice

def roll_action (dice):
    roll_two_die (dice)
    sum_of_dice = sum_dice (dice)
    return sum_of_dice
